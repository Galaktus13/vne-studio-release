
/* VNE STUDIO — self-contained front-end demo. No server, payments or real accounts. */
(() => {
  'use strict';
  const products = window.VNE_PRODUCTS || [];
  const byId = new Map(products.map(p => [p.id, p]));
  const storageKey = 'vne.studio.demo.v1';
  const $ = (s, root = document) => root.querySelector(s);
  const $$ = (s, root = document) => [...root.querySelectorAll(s)];
  const esc = (value) => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const money = (n) => new Intl.NumberFormat('ru-RU').format(n) + ' ₽';
  const icons = {
    arrow: '<path d="M5 12h14M13 6l6 6-6 6"/>',
    diagonal: '<path d="M6 18 18 6M6 6h12v12"/>',
    back: '<path d="M19 12H5m6-6-6 6 6 6"/>',
    search: '<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 4 4"/>',
    heart: '<path d="M20.8 4.9a5.5 5.5 0 0 0-7.8 0L12 6l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8L12 21l8.8-8.3a5.5 5.5 0 0 0 0-7.8Z"/>',
    bag: '<path d="M5 8h14l1.2 13H3.8L5 8Z"/><path d="M8 9V6a4 4 0 0 1 8 0v3"/>',
    user: '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
    menu: '<path d="M4 7h16M4 12h16M4 17h16"/>',
    close: '<path d="m6 6 12 12M18 6 6 18"/>',
    check: '<path d="m5 12 4 4L19 6"/>',
    grid: '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
    home: '<path d="m3 10 9-7 9 7v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1V10Z"/>',
    lock: '<rect x="5" y="10" width="14" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3m-4 5v2"/>',
    share: '<path d="M12 16V3m-4 4 4-4 4 4M5 12v7a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-7"/>',
    star: '<path d="m12 2 2.8 6 6.7 1-4.8 4.7 1.1 6.6-5.8-3.1-5.8 3.1 1.1-6.6L2.5 9l6.7-1L12 2Z"/>',
    spark: '<path d="M12 2v20M2 12h20M5 5l14 14M19 5 5 19"/>',
    globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c5 5 5 13 0 18-5-5-5-13 0-18Z"/>',
    info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v6m0-10v.2"/>',
    trash: '<path d="M4 6h16M9 6V3h6v3M6 6l1 15h10l1-15M10 10v7m4-7v7"/>',
    refresh: '<path d="M20 11a8 8 0 0 0-14-5L3 9m0-6v6h6M4 13a8 8 0 0 0 14 5l3-3m0 6v-6h-6"/>',
    download: '<path d="M12 3v12m-5-5 5 5 5-5M4 16v5h16v-5"/>'
  };
  const icon = name => `<svg viewBox="0 0 24 24" aria-hidden="true">${icons[name] || icons.arrow}</svg>`;
  const paintIcons = (root = document) => $$('[data-icon]', root).forEach(el => { el.innerHTML = icon(el.dataset.icon); });
  const categories = [ ['all','Все вещи'], ['cap','Кепки'], ['tee','Футболки'], ['hoodie','Худи'], ['socks','Носки'], ['sneakers','Кеды'] ];
  const collections = window.VNE_COLLECTIONS || [];
  const themeVars = p => `--art-accent:${p.accent};--art-accent-2:${p.accent2};--art-start:${p.bgStart};--art-end:${p.bgEnd};--art-base:${p.baseColor}`;
  const palette = p => `<span class="card-palette" aria-label="Палитра: ${esc(p.color)}"><i style="background:${p.baseColor}"></i><i style="background:${p.accent}"></i><i style="background:${p.accent2}"></i></span>`;
  const heroProduct = products.find(p=>p.id==='vne-sneakers-night-shift') || products[0];
  const homePicks = () => state.homeCategory==='all' ? products.slice(0,10) : products.filter(p=>p.cat===state.homeCategory);
  function validLine(x) {
    const p = byId.get(x?.id);
    return p && p.sizes.includes(x.size) && Number.isInteger(x.qty) && x.qty > 0 && x.qty <= 10;
  }
  function readStored() {
    try {
      const d = JSON.parse(localStorage.getItem(storageKey) || '{}');
      return {
        cart: Array.isArray(d.cart) ? d.cart.filter(validLine).slice(0,50) : [],
        favorites: Array.isArray(d.favorites) ? [...new Set(d.favorites)].filter(id=>byId.has(id)) : [],
        guest: d.guest === true,
        orders: Array.isArray(d.orders) ? d.orders.filter(o=> typeof o?.id==='string' && /^VNE-[A-Z0-9-]{5,30}$/.test(o.id) && Number.isFinite(Date.parse(o.date)) && Array.isArray(o.items) && o.items.length && o.items.every(validLine) && [0,500].includes(o.delivery)).slice(0,30) : []
      };
    } catch (_) { return {cart:[],favorites:[],guest:false,orders:[]}; }
  }
  const state = {...readStored(), homeCategory:'all', catalog:{}, currentProduct:null, selectedSize:null, delivery:0, cartStep:'cart', lastOrder:null, storageWarned:false};
  function save() {
    try { localStorage.setItem(storageKey, JSON.stringify({cart:state.cart,favorites:state.favorites,guest:state.guest,orders:state.orders})); }
    catch (_) { if (!state.storageWarned) { state.storageWarned=true; toast('Браузер не разрешил сохранение. Корзина работает до закрытия страницы.', 'info'); } }
  }
  function toast(message, symbol='check') {
    const el = document.createElement('div'); el.className='toast'; el.setAttribute('role','status');
    el.innerHTML=icon(symbol)+`<span>${esc(message)}</span>`; $('#toasts').appendChild(el);
    setTimeout(()=>{el.classList.add('out');setTimeout(()=>el.remove(),220);},3700);
  }
  const sum = (items=state.cart) => items.reduce((s,l)=>s+byId.get(l.id).price*l.qty,0);
  const count = () => state.cart.reduce((s,l)=>s+l.qty,0);
  function updateHeader() {
    $$('[data-cart-count]').forEach(e=>e.textContent=count());
    $('.cart-button').setAttribute('aria-label',`Открыть корзину: ${count()} товаров`);
    const fav=$('.favorite-header'); fav.setAttribute('aria-label',`Избранное: ${state.favorites.length} вещей`);
    fav.style.color=state.favorites.length?'#496a21':'';
  }
  function favoriteButton(p, extra='') {
    const on = state.favorites.includes(p.id);
    return `<button class="favorite-toggle ${on?'selected':''} ${extra}" data-action="favorite" data-id="${p.id}" aria-label="${on?'Убрать из избранного':'В избранное'}: ${esc(p.name)}" aria-pressed="${on}">${icon('heart')}</button>`;
  }
  function card(p, layout='catalog') {
    const photoSizes=layout==='related'
      ? '(max-width: 520px) calc(100vw - 32px), (max-width: 640px) calc((100vw - 57px) / 2), (max-width: 960px) calc((100vw - 84px) / 2), (max-width: 1150px) calc((100vw - 126px) / 4), (max-width: 1512px) calc((100vw - 158px) / 4), 339px'
      : '(max-width: 520px) calc(100vw - 32px), (max-width: 640px) calc((100vw - 57px) / 2), (max-width: 960px) calc((100vw - 84px) / 2), (max-width: 1150px) calc((100vw - 102px) / 3), (max-width: 1512px) calc((100vw - 144px) / 3), 456px';
    return `<article class="product-card" style="${themeVars(p)}" data-product-id="${p.id}">
      <div class="product-image"><a class="image-link" href="#/product/${p.id}" aria-label="Посмотреть ${esc(p.type+' '+p.name)}"><img src="${p.thumbnail}" srcset="${p.thumbnail} 640w, ${p.image} ${p.imageWidth}w" sizes="${photoSizes}" alt="${esc(p.type+' «'+p.name+'», '+p.color+' — концепт с рисунком «'+p.originalTitle+'»')}" loading="lazy" decoding="async" width="${p.imageWidth}" height="${p.imageHeight}"></a>
      <span class="card-edition">${esc(p.styleLabel)}</span>${favoriteButton(p)}
      <a href="#/product/${p.id}" class="quick-view">Рассмотреть вещь ${icon('diagonal')}</a></div>
      <div class="product-info"><div class="product-meta"><span>${esc(p.type)}</span>${palette(p)}</div>
      <div class="product-title-row"><a href="#/product/${p.id}" class="product-title">${esc(p.name)}</a><span class="product-price">${money(p.price)}</span></div>
      <div class="card-artline"><span>№ ${p.number}</span><span>${esc(p.collection)}</span></div></div></article>`;
  }
  const empty = (title,description,action='',symbol='search') => `<div class="empty-state"><span class="empty-icon">${icon(symbol)}</span><h3>${esc(title)}</h3><p>${esc(description)}</p>${action}</div>`;
  function chips(context, selected, base=products) {
    return categories.map(([id,label])=>`<button class="chip ${selected===id?'active':''}" data-action="${context}-filter" data-category="${id}" aria-pressed="${selected===id}">${label}<small>${id==='all'?base.length:base.filter(p=>p.cat===id).length}</small></button>`).join('');
  }
  function collectionCards() {
    return collections.map(c=>{
      const p=byId.get(c.asset);
      return `<a class="collection-card" style="${themeVars(p)}" href="${catalogHref({collection:c.name})}"><img src="${p.artImage}" alt="Рисунок для коллекции «${esc(c.name)}»" width="1000" height="1000" loading="lazy"><div class="collection-content"><div class="eyebrow">${c.tag} / ${products.filter(x=>x.collection===c.name).length} ВЕЩЕЙ</div><h3>${esc(c.name)}</h3><p>${esc(c.sub)}</p><span class="round-arrow">${icon('diagonal')}</span></div></a>`;
    }).join('');
  }
  function categoryIndex() {
    return `<nav class="category-index" aria-label="Пять категорий">${categories.slice(1).map(([id,title],i)=>`<a class="category-link" href="${catalogHref({category:id})}"><span class="category-number">0${i+1} / 10 ВЕЩЕЙ</span><strong>${title}</strong>${icon('diagonal')}</a>`).join('')}</nav>`;
  }
  function demoCallout() {
    return `<aside class="demo-callout">${icon('info')}<div><h3>Это демоверсия, а не действующий магазин</h3><p>Все изображения — макеты, цены — примеры. Здесь можно изучить коллекции и оформить тестовый заказ. Оплата, реальная регистрация и отправка заказов не подключены. Данные корзины и избранного сохраняются только в этом браузере, если он разрешает локальное хранение.</p></div></aside>`;
  }
  function renderHome() {
    const featured = homePicks();
    return `<div class="page"><section class="hero wrap"><div class="hero-copy"><div class="eyebrow"><span class="tiny-line"></span>НЕЗАВИСИМАЯ АРТ-СТУДИЯ / ART DROP / 50</div><h1><span class="ink-outline">Искусство.</span><br><em class="marked">Вне рамок.</em></h1><p class="hero-description">Одежда как способ сказать, кто ты.<br>Авторская графика, уличная энергия<br>и ни одного скучного правила.</p><div class="hero-actions"><a class="button" href="#/catalog">Найти своё ${icon('diagonal')}</a><a class="text-button" href="#/lookbook">Смотреть лукбук ${icon('arrow')}</a></div><div class="hero-foot"><div class="hero-mini" aria-hidden="true"><span>✳</span><span>↗</span><span>V</span></div><span><strong>Не для всех. Для тебя.</strong><br>50 вещей · 5 категорий · один характер</span></div></div><div class="hero-art"><a href="#/product/${heroProduct.id}" class="hero-image" style="display:block" aria-label="Открыть кеды ${esc(heroProduct.name)}"><span class="image-corner">ОБЪЕКТ № ${heroProduct.number}</span><img src="${heroProduct.image}" alt="${esc(heroProduct.type+' «'+heroProduct.name+'» — концепт')}" fetchpriority="high" width="1000" height="1000"><span class="hero-image-bottom"><span><small>ДВИЖЕНИЕ / ART CONCEPT</small><strong>${esc(heroProduct.name)} — искусство в движении</strong></span><span class="round-arrow">${icon('diagonal')}</span></span></a><span class="hero-sticker"><span class="asterisk">✳</span>ОДЕЖДА<br>С ХАРАКТЕРОМ</span><div class="hero-note"><span>VNE STUDIO — WEAR YOUR ART</span><span>001 / 2026</span></div></div></section><div class="marquee" aria-hidden="true"><div class="marquee-inner">${Array(4).fill('<span>НОСИ ИСКУССТВО</span><span class="star">✳</span><span>ВЫХОДИ ЗА РАМКИ</span><span class="star">✳</span><span>БУДЬ ВНЕ ШАБЛОНОВ</span><span class="star">✳</span>').join('')}</div></div><section class="section wrap" id="drop"><div class="section-head"><div><div class="eyebrow">01 / ГРАФИКА В ДВИЖЕНИИ</div><h2>Не для всех.<br>Для тебя.</h2></div><a class="text-button" href="#/catalog">Вся коллекция ${icon('diagonal')}</a></div>${categoryIndex()}<div class="filters-row" id="home-filters" aria-label="Категории товаров">${chips('home',state.homeCategory)}</div><div class="product-grid" id="home-grid">${featured.map(card).join('')}</div><div class="grid-footer"><a href="#/catalog" class="button outline">Смотреть все 50 вещей ${icon('arrow')}</a></div></section><section class="wrap"><div class="manifesto"><div class="manifesto-copy"><div class="eyebrow">БОЛЬШЕ, ЧЕМ ПРОСТО ВЕЩИ</div><h2>Твой стиль.<br><em>Твои правила.</em></h2><p>Мы представили мир, где искусство не висит в галерее, а идёт с тобой по улице. VNE — концепция вещей для тех, кто не помещается в готовые рамки.</p><a class="text-button" href="#/about">Познакомиться со студией ${icon('diagonal')}</a></div><div class="manifesto-art" aria-hidden="true"><span class="art-mini-label">РАМКИ? НЕ СЛЫШАЛИ.</span><span class="big-symbol">✳</span><span class="manifesto-label">LESS RULES.<br>MORE YOU.</span></div></div></section><section class="section wrap"><div class="section-head"><div><div class="eyebrow">ПЯТЬ НАСТРОЕНИЙ / ОДИН ТЫ</div><h2>Выбирай свою сторону.</h2></div><span class="side-note">Разные истории. Общий язык.<br>Тот, на котором говоришь ты.</span></div><div class="collection-grid">${collectionCards()}</div></section><div class="wrap"><section class="trust-row"><div class="trust-item">${icon('spark')}<div><strong>Графика с характером</strong><p>От геометрического попугая до ночного города.</p></div></div><div class="trust-item">${icon('globe')}<div><strong>Открытый просмотр</strong><p>Изучай весь каталог без регистрации и входа.</p></div></div><div class="trust-item">${icon('lock')}<div><strong>Никаких настоящих списаний</strong><p>Заказ полностью тестовый. Платёжных полей нет.</p></div></div></section><section class="bottom-banner"><div><h3>Хорошие вещи хочется показать.</h3><p>Познакомь друзей с VNE STUDIO.</p></div><button class="button outline" data-action="share">Показать другу ${icon('share')}</button></section></div></div>`;
  }
  function catalogHref(overrides={}) {
    const s={category:'all',collection:'',query:'',sort:'curated',price:'all',...overrides};
    const params=new URLSearchParams();
    if(s.category && s.category!=='all')params.set('category',s.category);
    if(s.collection)params.set('collection',s.collection);
    if(s.query)params.set('q',s.query);
    if(s.sort && s.sort!=='curated')params.set('sort',s.sort);
    if(s.price && s.price!=='all')params.set('price',s.price);
    return '#/catalog'+(params.toString()?'?'+params.toString():'');
  }
  function parseCatalog(params) {
    return {
      category:categories.some(([id])=>id===params.get('category'))?params.get('category'):'all',
      collection:collections.some(c=>c.name===params.get('collection'))?params.get('collection'):'',
      query:(params.get('q')||'').slice(0,100),
      sort:['price-asc','price-desc','name'].includes(params.get('sort'))?params.get('sort'):'curated',
      price:['under5000','5000to10000','over10000'].includes(params.get('price'))?params.get('price'):'all'
    };
  }
  function filterProducts(s) {
    const q=s.query.trim().toLocaleLowerCase('ru-RU');
    let list=products.filter(p=>(s.category==='all'||p.cat===s.category)&&(!s.collection||p.collection===s.collection)&&(!q||[p.name,p.type,p.color,p.collection,p.detail,p.originalTitle,p.styleLabel].join(' ').toLocaleLowerCase('ru-RU').includes(q))&&(s.price==='all'||(s.price==='under5000'&&p.price<5000)||(s.price==='5000to10000'&&p.price>=5000&&p.price<=10000)||(s.price==='over10000'&&p.price>10000)));
    if(s.sort==='price-asc')list.sort((a,b)=>a.price-b.price);
    if(s.sort==='price-desc')list.sort((a,b)=>b.price-a.price);
    if(s.sort==='name')list.sort((a,b)=>a.name.localeCompare(b.name));
    return list;
  }
  function catalogGrid() {
    const list=filterProducts(state.catalog);
    return list.length?list.map(card).join(''):empty('Пока ничего не нашлось','Попробуй другой запрос или сбрось фильтры. Твоя вещь где-то рядом.','<button class="button" data-action="reset-filters">Сбросить фильтры</button>');
  }
  function renderCatalog(params) {
    state.catalog=parseCatalog(params);
    const c=state.catalog;
    const base=c.collection?products.filter(p=>p.collection===c.collection):products;
    return `<div class="page catalog-page wrap"><section class="page-top"><div class="breadcrumb"><a href="#/">Главная</a><span>/</span><span>Каталог</span></div><div class="page-title-row"><h1 class="page-heading">Найди своё.</h1><span class="count-label" id="catalog-count">Найдено: ${filterProducts(c).length}</span></div><p class="page-intro">Не подстраивайся под одежду. Выбирай ту, которая говорит на твоём языке.</p></section>${c.collection?`<div class="active-collection"><span>Коллекция <strong>${esc(c.collection)}</strong></span><button data-action="clear-collection">Все коллекции ${icon('close')}</button></div>`:''}<div class="catalog-toolbar"><div class="filters-row" id="catalog-filters" aria-label="Категории">${chips('catalog',c.category,base)}</div></div><div class="catalog-controls"><label class="catalog-search">${icon('search')}<input id="catalog-query" type="search" maxlength="100" placeholder="Название, принт или настроение" value="${esc(c.query)}" aria-label="Поиск в каталоге"></label><label class="select-wrap"><select id="catalog-sort" aria-label="Сортировка"><option value="curated">Выбор студии</option><option value="price-asc">Сначала дешевле</option><option value="price-desc">Сначала дороже</option><option value="name">По названию</option></select></label><label class="select-wrap"><select id="catalog-price" aria-label="Диапазон цен"><option value="all">Любая цена</option><option value="under5000">До 5 000 ₽</option><option value="5000to10000">5 000–10 000 ₽</option><option value="over10000">Более 10 000 ₽</option></select></label></div><div id="catalog-grid" class="product-grid">${catalogGrid()}</div><p class="catalog-message">Демонстрационные товары и цены. Оформление заказа не приводит к покупке.</p></div>`;
  }
  function updateCatalog() {
    if(!$('#catalog-grid'))return;
    $('#catalog-grid').innerHTML=catalogGrid();
    $('#catalog-count').textContent='Найдено: '+filterProducts(state.catalog).length;
    try{history.replaceState(null,'',catalogHref(state.catalog));}catch(_){}
  }
  function renderProduct(id) {
    const p=byId.get(id);
    if(!p)return `<div class="page wrap section">${empty('Такой вещи нет в этом дропе','Ссылка могла измениться. В каталоге есть ещё много интересного.','<a class="button" href="#/catalog">Перейти в каталог</a>')}</div>`;
    state.currentProduct=p;state.selectedSize=p.sizes.length===1?p.sizes[0]:null;state.galleryView='product';
    const related=products.filter(x=>x.id!==p.id).sort((a,b)=>(b.collection===p.collection)-(a.collection===p.collection)||(b.cat===p.cat)-(a.cat===p.cat)).slice(0,4);
    return `<div class="page wrap product-page" style="${themeVars(p)}">
      <div class="page-top"><div class="breadcrumb"><a href="#/">Главная</a><span>/</span><a href="${catalogHref({category:p.cat})}">${esc(p.categoryTitle)}</a><span>/</span><span>${esc(p.name)}</span></div></div>
      <section class="product-detail">
        <div class="product-gallery"><div class="detail-image" id="detail-image">
          <img id="detail-visual" data-action="zoom" src="${p.image}" alt="${esc(p.type+' «'+p.name+'» — макет с рисунком «'+p.originalTitle+'»')}" width="${p.imageWidth}" height="${p.imageHeight}" tabindex="0" role="button" aria-label="Увеличить изображение ${esc(p.name)}">
          <span class="product-badge">ART OBJECT / ${p.number}</span>${favoriteButton(p)}<span class="image-tip">Нажми, чтобы рассмотреть</span>
        </div><div class="gallery-tabs" role="group" aria-label="Вид изображения товара">
          <button class="gallery-tab active" data-action="gallery-view" data-view="product" aria-pressed="true"><img src="${p.thumbnail}" alt="" width="48" height="48"><span>Изделие<small>${esc(p.styleLabel)}</small></span></button>
          <button class="gallery-tab" data-action="gallery-view" data-view="art" aria-pressed="false"><img src="${p.artImage}" alt="" width="42" height="48"><span>Исходный рисунок<small>Из подборки @__ruslan_99</small></span></button>
        </div><p class="gallery-caption" id="gallery-caption">Макет изделия · авторская графика в новом формате</p></div>
        <div class="detail-copy"><div class="detail-heading"><a class="eyebrow" href="${catalogHref({collection:p.collection})}">${esc(p.collection)} ${icon('diagonal')}</a><div class="detail-serial">VNE / ${p.number} / ART DROP</div><div class="detail-type">${esc(p.type)} <span class="detail-style">${esc(p.styleLabel)}</span></div><h1 class="detail-title">${esc(p.name)}</h1></div>
          <p class="detail-price">${money(p.price)}</p><p class="detail-tax">Демонстрационная цена</p><p class="detail-description">${esc(p.detail)}</p>
          <div class="variant-label">Палитра рисунка</div><div class="palette-line">${palette(p)}<span>${esc(p.color)}</span></div>
          <div class="variant-label"><span id="size-label">Размер${state.selectedSize?': '+esc(state.selectedSize):''}</span><button data-action="size-guide">О размерах</button></div>
          <div class="size-options" role="group" aria-label="Выбор размера">${p.sizes.map(size=>`<button class="size-button ${size===state.selectedSize?'selected':''}" data-action="size" data-size="${esc(size)}" aria-pressed="${size===state.selectedSize}">${esc(size)}</button>`).join('')}</div>
          <p class="size-hint" id="size-hint">${state.selectedSize?'Размер выбран. Можно добавить в корзину.':'Выбери размер для своей вещи.'}</p>
          <div class="detail-actions"><button class="button" id="add-to-cart" data-action="add" ${state.selectedSize?'':'disabled'}>${state.selectedSize?'Добавить в корзину':'Выбери размер'} ${icon('bag')}</button><button class="icon-button" data-action="share" aria-label="Поделиться этой вещью">${icon('share')}</button></div>
          <p class="detail-legal">${icon('lock')}Демо-примерка: тестовая корзина без оплаты</p>
          <details class="accordion" open><summary>Характер вещи</summary><p><strong>${esc(p.styleLabel)}</strong> · ${esc(p.placementLabel)}. ${esc(p.styleNote)}${p.variantNote?' '+esc(p.variantNote):''}</p></details>
          <details class="accordion"><summary>О рисунке</summary><p>${esc(p.originalTitle)}. В основе — изображение из профиля @__ruslan_99. Ниже можно рассмотреть исходную композицию и перейти к публикации.</p></details>
          <details class="accordion"><summary>Демо-заказ и доставка</summary><p>Выбранная вещь сохраняется в корзине этого браузера. Можно оформить тестовый заказ с самовывозом или демонстрационной доставкой за 500 ₽. Реальные продажи, оплата и отправка не подключены.</p></details>
        </div>
      </section>
      <section class="source-story" aria-labelledby="source-title"><a class="source-art" href="${esc(p.sourceUrl)}" target="_blank" rel="noopener noreferrer" aria-label="Исходная публикация: ${esc(p.originalTitle)}"><img src="${p.artImage}" alt="${esc(p.originalTitle)} — исходный рисунок" loading="lazy" decoding="async" width="1000" height="800"><span>ОТ РИСУНКА К ВЕЩИ ${icon('diagonal')}</span></a><div class="source-copy"><div class="eyebrow">ИСТОЧНИК ВДОХНОВЕНИЯ / ${p.number}</div><h2 id="source-title">${esc(p.originalTitle)}</h2><p>${esc(p.artStory)}</p><div class="palette-line">${palette(p)}<span>${esc(p.color)}</span></div><a class="text-button" href="${esc(p.sourceUrl)}" target="_blank" rel="noopener noreferrer">Рисунок в @__ruslan_99 ${icon('diagonal')}</a><p class="source-footnote">Вещь показана как концепт коллекции. Исходный рисунок можно открыть отдельно.</p></div></section>
      <section class="related-section"><div class="section-head"><div><div class="eyebrow">ПРОДОЛЖЕНИЕ ТВОЕЙ ИСТОРИИ</div><h2>В одном настроении.</h2></div><a class="text-button" href="#/catalog">Весь каталог ${icon('diagonal')}</a></div><div class="product-grid">${related.map(product=>card(product,'related')).join('')}</div></section>
    </div>`;
  }
  function setGalleryView(view) {
    const p=state.currentProduct;if(!p||!['product','art'].includes(view))return;
    state.galleryView=view;
    const original=view==='art',img=$('#detail-visual'),stage=$('#detail-image');
    img.src=original?p.artImage:p.image;
    img.alt=original?p.originalTitle+' — исходный рисунок':p.type+' «'+p.name+'» — макет изделия';
    img.setAttribute('aria-label','Увеличить '+(original?'исходный рисунок':'изображение '+p.name));
    stage.classList.remove('zoomed');stage.classList.toggle('art-view',original);
    $$('.gallery-tab').forEach(button=>{const on=button.dataset.view===view;button.classList.toggle('active',on);button.setAttribute('aria-pressed',String(on));});
    $('#gallery-caption').textContent=original?p.originalTitle+' · @__ruslan_99':'Макет изделия · авторская графика в новом формате';
  }
  function renderFavorites() {
    const list=products.filter(p=>state.favorites.includes(p.id));
    return `<div class="page catalog-page wrap"><section class="page-top"><div class="breadcrumb"><a href="#/">Главная</a><span>/</span><span>Избранное</span></div><div class="page-title-row"><h1 class="page-heading">Твоя подборка.</h1><span class="count-label" id="favorites-count">Вещей: ${list.length}</span></div><p class="page-intro">Вещи, на которых остановился взгляд. Сохраняются в этом браузере — без аккаунта.</p></section><div class="product-grid" id="favorites-grid">${list.length?list.map(card).join(''):empty('Здесь будет твой характер','Нажми на сердечко у понравившейся вещи. Она появится в этой подборке.','<a class="button" href="#/catalog">Найти любимую вещь '+icon('diagonal')+'</a>','heart')}</div></div>`;
  }
  function renderCollections() {
    return `<div class="page editorial-page wrap"><section class="page-top"><div class="breadcrumb"><a href="#/">Главная</a><span>/</span><span>Коллекции</span></div><h1 class="page-heading">На твоей частоте.</h1><p class="page-intro">Пять коллекций по настроению рисунков. Цвет, буквы, движение, истории и форма.</p></section><div class="collection-grid collection-hero-grid">${collectionCards()}</div><div class="editorial-note"><div class="eyebrow">ПРАВИЛО № 001</div><p>Не обязательно выбирать одну сторону. Смешивай яркое с тихим, городское с личным. Собирай не гардероб, а собственную историю.</p></div><div style="margin-top:35px">${demoCallout()}</div></div>`;
  }
  function renderLookbook() {
    const concepts=[
      ['tee','color','Цвет говорит первым.','Начни с выразительного принта. Дальше достаточно простой базы.'],
      ['sneakers','motion','Город под ногами.','Графика меняет характер привычного силуэта. Каждый шаг становится частью истории.'],
      ['hoodie','street','Буквы без рамок.','Масштаб уличной росписи встречается со свободной формой худи.'],
      ['cap','mono','Деталь с позицией.','Спокойная палитра, точная графика и один выразительный акцент.'],
      ['socks','stories','Искусство в деталях.','Небольшая вещь может задать настроение целому образу.']
    ];
    const looks=concepts.map(([kind,collection,name,text],i)=>({p:products.find(p=>p.cat===kind&&p.collectionId===collection)||products.find(p=>p.cat===kind),n:String(i+1).padStart(2,'0'),name,text}));
    return `<div class="page editorial-page wrap"><section class="page-top"><div class="breadcrumb"><a href="#/">Главная</a><span>/</span><span>Лукбук</span></div><h1 class="page-heading">Так выглядит свобода.</h1><p class="page-intro">Пять способов носить рисунок. Пять характеров — от крупного принта до небольшого акцента.</p></section><div class="look-grid">${looks.map(l=>{const p=l.p;return `<article class="look-card" style="${themeVars(p)}"><a class="look-photo" style="display:block" href="#/product/${p.id}"><img src="${p.image}" alt="${esc(p.type+' '+p.name)} — концепт для лукбука" width="${p.imageWidth}" height="${p.imageHeight}" loading="lazy"></a><div class="look-caption"><div><div class="eyebrow">LOOK ${l.n} / ${esc(p.categoryTitle)}</div><h2>${l.name}</h2><p>${l.text}</p></div><a class="round-arrow" href="#/product/${p.id}" aria-label="Открыть ${esc(p.name)}">${icon('diagonal')}</a></div></article>`;}).join('')}</div></div>`;
  }
  function renderAbout() {
    return `<div class="page editorial-page wrap"><div class="page-top"><div class="breadcrumb"><a href="#/">Главная</a><span>/</span><span>О студии</span></div></div><section class="about-hero"><div><div class="eyebrow">VNE STUDIO / МАНИФЕСТ</div><h1>Искусство не обязано<br>жить <em>в рамке.</em></h1><p>Оно может гулять по городу, опаздывать на встречу, ехать навстречу закату. VNE STUDIO — концепция магазина, в котором вещи становятся маленькими личными манифестами.</p></div><div class="about-symbol" aria-hidden="true"><span class="big-symbol">✳</span><span class="art-mini-label">OUTSIDE THE LINES / SINCE NOW</span></div></section><div class="principles"><article class="principle"><small>01 / ХАРАКТЕР</small><h2>Заметно. По-своему.</h2><p>Цвет, графика и детали не должны всем нравиться. Достаточно, чтобы в них узнал себя ты.</p></article><article class="principle"><small>02 / СВОБОДА</small><h2>Без готовых ролей.</h2><p>Вчера яркий принт, сегодня спокойная база. Твой стиль не обязан давать объяснения.</p></article><article class="principle"><small>03 / ДВИЖЕНИЕ</small><h2>Из искусства в жизнь.</h2><p>От графики к предмету, от предмета — к твоей истории. Самая интересная галерея всегда снаружи.</p></article></div>${demoCallout()}<div class="editorial-note"><div class="eyebrow">ОБ ИЗОБРАЖЕНИЯХ</div><div><p style="font-size:16px">В основе коллекции — 45 изображений из сохранённой подборки @__ruslan_99. Из них собраны 50 концептов: по 10 кепок, футболок, худи, пар носков и кед. Пять рисунков получили дополнительную интерпретацию. На странице каждой вещи есть исходный рисунок и ссылка на публикацию.</p><a class="text-button" style="margin-top:20px" href="https://www.instagram.com/__ruslan_99/" target="_blank" rel="noopener noreferrer">Смотреть исходные рисунки ${icon('diagonal')}</a></div></div></div>`;
  }
  function closeAll() { $$('dialog[open]').forEach(d=>d.close());document.body.style.overflow=''; }
  function openDialog(id,html,focus) {
    const d=$('#'+id);
    $$('dialog[open]').filter(x=>x!==d).forEach(x=>x.close());
    d.innerHTML=html;
    if(!d.open)d.showModal();
    document.body.style.overflow='hidden';
    if(focus)requestAnimationFrame(()=>$(focus,d)?.focus());
    return d;
  }
  const dialogHead=(title,id,extra='')=>`<div class="dialog-head"><h2 id="${id}">${title}${extra}</h2><button class="icon-button" data-action="close" aria-label="Закрыть окно">${icon('close')}</button></div>`;
  function showCart() {state.cartStep='cart';renderCart();}
  function renderCart() {
    if(state.cartStep==='checkout')return renderCheckout();
    if(state.cartStep==='success')return renderSuccess();
    const focused=document.activeElement?.dataset;
    const html=dialogHead('Корзина','cart-title',`<small>${count()}</small>`)+`<div class="dialog-content"><div class="sheet-note">Демо-режим: это не покупка. Все цены тестовые. Личные и платёжные данные не нужны.</div>${state.cart.length?state.cart.map((l,i)=>{const p=byId.get(l.id);return `<article class="cart-item"><a class="cart-thumb" href="#/product/${p.id}"><img src="${p.thumbnail}" alt="${esc(p.name)}" width="640" height="640"></a><div><div class="cart-item-top"><div><h3><a href="#/product/${p.id}">${esc(p.name)}</a></h3><p>${esc(p.type)}</p></div><button class="remove-item" data-action="remove" data-index="${i}" aria-label="Убрать ${esc(p.name)} из корзины">${icon('close')}</button></div><div class="cart-variant">${esc(l.size)} · ${esc(p.color)}</div><div class="cart-item-bottom"><div class="quantity"><button data-action="quantity" data-index="${i}" data-delta="-1" aria-label="Уменьшить количество ${esc(p.name)}" ${l.qty===1?'disabled':''}>−</button><span aria-label="Количество">${l.qty}</span><button data-action="quantity" data-index="${i}" data-delta="1" aria-label="Увеличить количество ${esc(p.name)}" ${l.qty>=10?'disabled':''}>+</button></div><span class="cart-item-price">${money(p.price*l.qty)}</span></div></div></article>`;}).join(''):`<div class="sheet-empty">${icon('bag')}<h3>Всё начинается с одной вещи.</h3><p>Выбери ту, которая подходит твоему настроению. Мы подержим её здесь.</p><a class="button" href="#/catalog">Перейти в каталог ${icon('diagonal')}</a></div>`}</div>${state.cart.length?`<div class="cart-summary"><div class="total-row"><span>Итого</span><strong>${money(sum())}</strong></div><button class="button full" data-action="checkout">К тестовому оформлению ${icon('arrow')}</button><p class="summary-hint">Доставка выбирается на следующем шаге.</p></div>`:''}`;
    const d=openDialog('cart-dialog',html);
    if(focused?.action==='quantity')$(`[data-action="quantity"][data-index="${focused.index}"][data-delta="${focused.delta}"]`,d)?.focus();
  }
  function renderCheckout() {
    if(!state.cart.length){state.cartStep='cart';return renderCart();}
    const subtotal=sum();
    openDialog('cart-dialog',dialogHead('Тестовый заказ','cart-title')+`<div class="dialog-content"><div class="step-label">01 / КОРЗИНА → 02 / ОФОРМЛЕНИЕ</div><h3 class="checkout-title">Примерим оформление.</h3><div class="sheet-note">Покупка не произойдёт. Ни адрес, ни телефон, ни банковская карта не запрашиваются.</div><p style="font-size:12px;font-weight:600">Вариант получения</p><label class="delivery-option"><input type="radio" name="demo-delivery" value="0" ${state.delivery===0?'checked':''}><span>Самовывоз<small>Тестовый вариант, без реального пункта</small></span><strong>0 ₽</strong></label><label class="delivery-option"><input type="radio" name="demo-delivery" value="500" ${state.delivery===500?'checked':''}><span>Доставка<small>Демонстрационный тариф</small></span><strong>500 ₽</strong></label><div class="checkout-explain">Заказ сохранится только в истории этого браузера. Никому не отправится заявка, никто не будет звонить, товар не будет отгружен.</div><button class="text-button" data-action="back-cart" style="margin-top:23px">${icon('back')}Вернуться в корзину</button></div><div class="cart-summary"><div class="order-row"><span>Товары · ${count()} шт.</span><span>${money(subtotal)}</span></div><div class="order-row"><span>Тестовая доставка</span><span id="delivery-cost">${money(state.delivery)}</span></div><div class="total-row"><span>Итого</span><strong id="checkout-total">${money(subtotal+state.delivery)}</strong></div><button class="button full" data-action="place-order">Оформить тестовый заказ ${icon('check')}</button><p class="summary-hint">Деньги не списываются. Это демонстрация интерфейса.</p></div>`);
  }
  function placeOrder() {
    if(state.cartStep!=='checkout'||!state.cart.length)return;
    const order={id:'VNE-'+Date.now().toString(36).toUpperCase(),date:new Date().toISOString(),items:state.cart.map(x=>({...x})),delivery:state.delivery};
    state.orders.unshift(order);state.orders=state.orders.slice(0,30);state.lastOrder=order;state.cart=[];state.cartStep='success';save();updateHeader();renderSuccess();
  }
  function renderSuccess() {
    const o=state.lastOrder;
    if(!o){state.cartStep='cart';return renderCart();}
    openDialog('cart-dialog',dialogHead('Готово','cart-title')+`<div class="dialog-content success-content"><span class="success-icon">${icon('check')}</span><div class="eyebrow" style="justify-content:center">ТЕСТ ПРОЙДЕН / СТИЛЬ ВЫБРАН</div><h3>Хороший выбор.<br>В твоём характере.</h3><p>Тестовый заказ создан и сохранён в этом браузере. Настоящего заказа нет — ничего оплачивать не нужно.</p><div class="order-number">${esc(o.id)}</div><div class="order-row" style="margin-top:18px"><span>Демонстрационная сумма</span><strong>${money(sum(o.items)+o.delivery)}</strong></div><div class="success-actions"><button class="button full" data-action="profile">Посмотреть историю ${icon('arrow')}</button><button class="button outline full" data-action="export-order">Сохранить тестовый заказ ${icon('download')}</button><a class="text-button" href="#/catalog">Вернуться в каталог</a></div></div>`);
  }
  function showSearch() {
    openDialog('search-dialog',dialogHead('Что ищем?','search-title')+`<label class="search-field">${icon('search')}<input id="search-input" type="search" maxlength="100" placeholder="Например, кеды или попугай" aria-label="Поиск товаров" autocomplete="off"></label><div class="search-results" id="search-results"></div><p class="search-hint">Название, цвет, категория или настроение.</p>`,'#search-input');
    updateSearch('');
  }
  function updateSearch(query) {
    const q=query.trim().toLocaleLowerCase('ru-RU');
    const list=products.filter(p=>!q||[p.name,p.type,p.color,p.detail,p.collection,p.originalTitle,p.styleLabel].join(' ').toLocaleLowerCase('ru-RU').includes(q));
    $('#search-results').innerHTML=list.length?list.map(p=>`<a class="search-result" href="#/product/${p.id}"><img src="${p.thumbnail}" alt="" width="55" height="55"><div><h3>${esc(p.name)}</h3><p>${esc(p.type)}</p></div><span>${money(p.price)}</span></a>`).join(''):'<p class="search-empty">Совпадений нет. Попробуй «носки», «кеды» или «попугай».</p>';
  }
  function showProfile() {
    const orderCards=state.orders.map(o=>`<article class="saved-order"><div class="saved-order-head"><strong>${esc(o.id)}</strong><span class="test-badge">Тестовый</span></div><div class="saved-order-date">${new Intl.DateTimeFormat('ru-RU',{day:'numeric',month:'long',hour:'2-digit',minute:'2-digit'}).format(new Date(o.date))}</div><div class="saved-order-thumbs">${o.items.map(l=>`<a href="#/product/${l.id}" aria-label="${esc(byId.get(l.id).name)}"><img src="${byId.get(l.id).thumbnail}" alt="${esc(byId.get(l.id).name)}" width="46" height="46"></a>`).join('')}</div><div class="saved-order-bottom"><span>${o.items.reduce((s,l)=>s+l.qty,0)} шт. · ${o.delivery?'доставка':'самовывоз'}</span><strong>${money(sum(o.items)+o.delivery)}</strong></div></article>`).join('');
    openDialog('profile-dialog',dialogHead('Демо-профиль','profile-title')+`<div class="dialog-content"><div class="profile-avatar">В</div><h3 class="profile-name">${state.guest?'Гость студии.':'Будь как дома.'}</h3><p>Просмотр, избранное и корзина работают без входа. Здесь нет настоящей регистрации: пароль, почта и номер телефона не нужны.</p>${state.guest?'<div class="sheet-note" style="margin-top:22px">Гостевой режим активен. Это локальный демо-профиль, а не учётная запись.</div>':'<button class="button full" data-action="guest">Открыть гостевой профиль '+icon('arrow')+'</button>'}<h3 class="profile-section-title">История тестовых заказов <span class="muted">(${state.orders.length})</span></h3>${state.orders.length?orderCards:'<p style="font-size:12px;color:var(--muted)">Здесь пока тихо. После тестового оформления заказ появится в истории этого браузера.</p>'}<a class="text-button" style="margin-top:24px" href="#/favorites">Избранные вещи · ${state.favorites.length} ${icon('heart')}</a></div><div class="profile-footer"><button data-action="info" data-info="privacy">Где хранятся данные</button><button data-action="reset-confirm">Сбросить демо</button></div>`);
  }
  const infoContent = {
    demo:{title:'Это живая демоверсия.',html:'<p>Каталог, категории, поиск, сортировка, карточки товаров, размеры, избранное и корзина интерактивны. Можно пройти весь сценарий тестового заказа без входа.</p><p>Товары, иллюстрации и цены — демонстрационные. Платежи, настоящая регистрация, отправка заявок и доставка не подключены.</p><p>Корзина, избранное и история хранятся только в этом браузере, когда локальное хранение доступно. Это не общая база между устройствами.</p>'},
    delivery:{title:'Доставка без неожиданностей.',html:'<p>В этой версии доставка — часть демонстрации. В оформлении доступны самовывоз за 0 ₽ и тестовая доставка за 500 ₽. Реальные адреса, сроки, перевозчики и тарифы не установлены.</p><p>Посылки не отправляются, покупки не совершаются. Правила реальных продаж и возврата должны быть подготовлены отдельно перед запуском магазина.</p>'},
    privacy:{title:'Остаётся в твоём браузере.',html:'<p>Демо не просит имя, телефон, почту, пароль или данные банковской карты. Аналитики, рекламных трекеров и загрузки внешних шрифтов здесь нет.</p><p>Корзина, избранное, гостевой статус и до 30 тестовых заказов сохраняются в localStorage этого браузера. В другой браузер или на другое устройство они не синхронизируются.</p><p>Кнопка «Сбросить демо» удаляет только данные этого сайта. В закрытом режиме или при запрете хранения данные могут исчезнуть при закрытии страницы. Внешняя ссылка Instagram открывается только по твоему нажатию.</p>'},
    sizes:{title:'Сначала — твой размер.',html:'<p>В демо размеры нужны, чтобы проверить выбор варианта товара и работу корзины. Подтверждённых обмеров реальных изделий пока нет, поэтому таблица сантиметров не выдумывается.</p><table class="info-table"><thead><tr><th>Категория</th><th>Доступный выбор в демо</th></tr></thead><tbody><tr><td>Одежда</td><td>XS–XXL, зависит от модели</td></tr><tr><td>Кеды</td><td>36–45</td></tr><tr><td>Носки</td><td>36–40 / 41–45</td></tr><tr><td>Кепки</td><td>S/M · L/XL · универсальный</td></tr></tbody></table><p>Эти обозначения не являются рекомендацией по посадке. Перед реальными продажами нужны проверенные мерки каждой модели.</p>'}
  };
  function showInfo(key) {
    const d=infoContent[key]||infoContent.demo;
    openDialog('info-dialog',dialogHead(d.title,'info-title')+`<div class="dialog-content">${d.html}<button class="button full" data-action="close">Понятно ${icon('check')}</button></div>`);
  }
  function showMenu() {
    openDialog('menu-dialog',dialogHead('ВНЕ / МЕНЮ','menu-title')+`<nav class="menu-links" aria-label="Разделы сайта"><a href="#/">Главная ↗</a><a href="#/catalog">Каталог</a><a href="#/collections">Коллекции</a><a href="#/lookbook">Лукбук</a><a href="#/about">О студии</a><a href="#/favorites">Избранное · ${state.favorites.length}</a></nav><div class="menu-bottom"><button class="text-button" data-action="profile">Демо-профиль ${icon('user')}</button><p style="margin-top:18px">Открытый просмотр. Без регистрации.<br>Настоящие продажи не подключены.</p></div>`);
  }
  async function share() {
    const http=/^https?:$/.test(location.protocol);
    const localHost=['localhost','127.0.0.1','0.0.0.0',''].includes(location.hostname);
    if(!http||localHost){
      openDialog('info-dialog',dialogHead('Покажи свой характер.','info-title')+`<div class="dialog-content"><p>Сейчас открыта локальная демоверсия. Чтобы показать её другу, перешли файл <strong>VNE-STUDIO-demo.html</strong>. В нём уже есть код и изображения; интернет для работы не нужен.</p><p>Локальный адрес не станет общей интернет-ссылкой. Для просмотра по публичному адресу демо нужно отдельно разместить на хостинге. После публикации эта кнопка поделится адресом страницы.</p><button class="button full" data-action="close">Понятно ${icon('check')}</button></div>`);return;
    }
    const data={title:'VNE STUDIO — искусство вне рамок',text:'Посмотри интерактивную демоверсию VNE STUDIO. Без регистрации.',url:location.href};
    try{
      if(navigator.share){await navigator.share(data);return;}
      if(navigator.clipboard?.writeText){await navigator.clipboard.writeText(location.href);toast('Ссылка скопирована. Покажи друзьям.');return;}
    }catch(e){if(e.name==='AbortError')return;}
    openDialog('info-dialog',dialogHead('Адрес этой страницы','info-title')+`<div class="dialog-content"><p>Скопируй адрес из строки браузера и отправь другу:</p><p style="overflow-wrap:anywhere;color:var(--ink)">${esc(location.href)}</p><button class="button full" data-action="close">Готово</button></div>`);
  }
  function toggleFavorite(id) {
    if(!byId.has(id))return;
    const was=state.favorites.includes(id);
    state.favorites=was?state.favorites.filter(x=>x!==id):[...state.favorites,id];
    save();updateHeader();
    if($('#favorites-grid')){
      const list=products.filter(p=>state.favorites.includes(p.id));
      $('#favorites-count').textContent='Вещей: '+list.length;
      $('#favorites-grid').innerHTML=list.length?list.map(card).join(''):empty('Здесь будет твой характер','Добавляй вещи сердечком — они сохранятся в твоей подборке.','<a class="button" href="#/catalog">В каталог '+icon('arrow')+'</a>','heart');
    } else {
      $$(`.favorite-toggle[data-id="${id}"]`).forEach(b=>{b.classList.toggle('selected',!was);b.setAttribute('aria-pressed',String(!was));b.setAttribute('aria-label',`${was?'В избранное':'Убрать из избранного'}: ${byId.get(id).name}`);});
    }
    toast(was?'Вещь убрана из избранного.':'Сохранено в твою подборку.',was?'check':'heart');
  }
  function chooseSize(size) {
    if(!state.currentProduct?.sizes.includes(size))return;
    state.selectedSize=size;
    $$('.size-button').forEach(b=>{const on=b.dataset.size===size;b.classList.toggle('selected',on);b.setAttribute('aria-pressed',on);});
    $('#size-label').textContent='Размер: '+size;
    $('#size-hint').textContent='Размер выбран. Можно добавить в тестовую корзину.';
    $('#add-to-cart').disabled=false;$('#add-to-cart').innerHTML='Добавить в корзину '+icon('bag');
  }
  function addToCart() {
    const p=state.currentProduct,size=state.selectedSize;
    if(!p||!size||!p.sizes.includes(size))return;
    const found=state.cart.find(l=>l.id===p.id&&l.size===size);
    if(found&&found.qty>=10){toast('В демо — не больше 10 одинаковых вещей одного размера.','info');return;}
    if(found)found.qty++;else state.cart.push({id:p.id,size,qty:1});
    save();updateHeader();toast(`${p.name} · ${size} — в корзине.`);
    const btn=$('#add-to-cart');btn.innerHTML='Добавлено '+icon('check');
    setTimeout(()=>{if(btn.isConnected)btn.innerHTML='Добавить ещё '+icon('bag');},1400);
  }
  function exportOrder() {
    const o=state.lastOrder;if(!o)return;
    const lines=['VNE STUDIO — ТЕСТОВЫЙ ЗАКАЗ',o.id,'','Это не покупка. Продажи и оплата не подключены.',''];
    o.items.forEach(l=>{const p=byId.get(l.id);lines.push(`${p.name} · ${p.type} · ${l.size} · ${l.qty} шт. × ${money(p.price)} = ${money(p.price*l.qty)}`);});
    lines.push('',`Товары: ${money(sum(o.items))}`,`Тестовая доставка: ${money(o.delivery)}`,`Итого: ${money(sum(o.items)+o.delivery)}`,'','Данные сохранены только в этом браузере. Заказ никому не отправлен.');
    const blob=new Blob(['\uFEFF'+lines.join('\n')],{type:'text/plain;charset=utf-8'}),url=URL.createObjectURL(blob);
    const a=document.createElement('a');a.href=url;a.download=o.id+'-TEST.txt';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),10000);
  }
  function resetConfirm() {
    openDialog('info-dialog',dialogHead('Начать с чистого листа?','info-title')+'<div class="dialog-content"><p>Корзина, избранное, гостевой статус и история тестовых заказов этого демо будут удалены из текущего браузера. Данные других сайтов не затрагиваются.</p><button class="button full dark" data-action="reset-demo">Да, сбросить демо</button><button class="button outline full" data-action="profile">Оставить как есть</button></div>');
  }
  function navigate(href) {closeAll();if(location.hash===href)route();else location.hash=href;}
  function route() {
    closeAll();state.currentProduct=null;state.selectedSize=null;
    const raw=(location.hash.startsWith('#/')?location.hash.slice(1):'/');
    const [path,query='']=raw.split('?');const params=new URLSearchParams(query);
    let html,title,active;
    if(path==='/'||path===''){html=renderHome();title='Искусство вне рамок';active='home';}
    else if(path==='/catalog'){html=renderCatalog(params);title='Каталог';active='catalog';}
    else if(path.startsWith('/product/')){const id=path.slice(9);html=renderProduct(id);title=byId.get(id)?.name||'Вещь не найдена';active='catalog';}
    else if(path==='/favorites'){html=renderFavorites();title='Избранное';active='favorites';}
    else if(path==='/collections'){html=renderCollections();title='Коллекции';active='collections';}
    else if(path==='/lookbook'){html=renderLookbook();title='Лукбук';active='lookbook';}
    else if(path==='/about'){html=renderAbout();title='О студии';active='about';}
    else{html=`<div class="page wrap section">${empty('Вышли за рамки страницы.','Такого раздела нет. Вернёмся туда, где есть хорошие вещи.','<a class="button" href="#/">На главную '+icon('arrow')+'</a>')}</div>`;title='Страница не найдена';active='';}
    $('#main').innerHTML=html;document.title='VNE STUDIO — '+title;
    $$('[data-nav]').forEach(a=>{const on=a.dataset.nav===active;a.classList.toggle('active',on);if(on)a.setAttribute('aria-current','page');else a.removeAttribute('aria-current');});
    $$('[data-mobile-nav]').forEach(a=>{const on=a.dataset.mobileNav===active;a.classList.toggle('active',on);if(on)a.setAttribute('aria-current','page');else a.removeAttribute('aria-current');});
    if($('#catalog-sort'))$('#catalog-sort').value=state.catalog.sort;
    if($('#catalog-price'))$('#catalog-price').value=state.catalog.price;
    window.scrollTo({top:0,behavior:'instant'});
    $('#main').focus({preventScroll:true});updateHeader();
  }
  document.addEventListener('click', e=>{
    const skip=e.target.closest('.skip-link');if(skip){e.preventDefault();$('#main').focus();$('#main').scrollIntoView();return;}
    const action=e.target.closest('[data-action]');
    if(action){
      const a=action.dataset.action;
      if(action.disabled)return;
      if(a==='close'){action.closest('dialog')?.close();document.body.style.overflow='';}
      else if(a==='cart')showCart();
      else if(a==='search')showSearch();
      else if(a==='profile')showProfile();
      else if(a==='menu')showMenu();
      else if(a==='info')showInfo(action.dataset.info);
      else if(a==='share')share();
      else if(a==='favorite')toggleFavorite(action.dataset.id);
      else if(a==='home-filter'){
        state.homeCategory=action.dataset.category;
        $('#home-filters').innerHTML=chips('home',state.homeCategory);
        const list=homePicks();
        $('#home-grid').innerHTML=list.map(card).join('');
        $(`#home-filters [data-category="${state.homeCategory}"]`)?.focus({preventScroll:true});
      }
      else if(a==='catalog-filter'){
        state.catalog.category=action.dataset.category;
        const base=state.catalog.collection?products.filter(p=>p.collection===state.catalog.collection):products;
        $('#catalog-filters').innerHTML=chips('catalog',state.catalog.category,base);updateCatalog();
        $(`#catalog-filters [data-category="${state.catalog.category}"]`)?.focus({preventScroll:true});
      }
      else if(a==='reset-filters')navigate('#/catalog');
      else if(a==='clear-collection')navigate(catalogHref({...state.catalog,collection:''}));
      else if(a==='zoom'){
        const on=$('#detail-image').classList.toggle('zoomed');
        action.setAttribute('aria-label',(on?'Уменьшить':'Увеличить')+' изображение '+state.currentProduct.name);
      }
      else if(a==='gallery-view')setGalleryView(action.dataset.view);
      else if(a==='size')chooseSize(action.dataset.size);
      else if(a==='size-guide')showInfo('sizes');
      else if(a==='add')addToCart();
      else if(a==='remove'){
        const i=Number(action.dataset.index);if(state.cart[i]){state.cart.splice(i,1);save();updateHeader();renderCart();}
      }
      else if(a==='quantity'){
        const l=state.cart[Number(action.dataset.index)],delta=Number(action.dataset.delta);
        if(l&&[1,-1].includes(delta)){l.qty=Math.min(10,Math.max(1,l.qty+delta));save();updateHeader();renderCart();}
      }
      else if(a==='checkout'){state.cartStep='checkout';state.delivery=0;renderCheckout();}
      else if(a==='back-cart'){state.cartStep='cart';renderCart();}
      else if(a==='place-order')placeOrder();
      else if(a==='export-order')exportOrder();
      else if(a==='guest'){state.guest=true;save();showProfile();}
      else if(a==='reset-confirm')resetConfirm();
      else if(a==='reset-demo'){
        state.cart=[];state.favorites=[];state.guest=false;state.orders=[];state.lastOrder=null;state.delivery=0;
        try{localStorage.removeItem(storageKey);}catch(_){}
        closeAll();route();toast('Демо сброшено. Чистый лист.');
      }
      return;
    }
    const link=e.target.closest('a[href^="#/"]');
    if(link&&!e.ctrlKey&&!e.metaKey&&!e.shiftKey&&!e.altKey){e.preventDefault();navigate(link.getAttribute('href'));}
  });
  document.addEventListener('input',e=>{
    if(e.target.id==='search-input')updateSearch(e.target.value);
    if(e.target.id==='catalog-query'){state.catalog.query=e.target.value;updateCatalog();}
  });
  document.addEventListener('change',e=>{
    if(e.target.id==='catalog-sort'){state.catalog.sort=e.target.value;updateCatalog();}
    if(e.target.id==='catalog-price'){state.catalog.price=e.target.value;updateCatalog();}
    if(e.target.name==='demo-delivery'){
      state.delivery=Number(e.target.value)===500?500:0;
      if($('#delivery-cost'))$('#delivery-cost').textContent=money(state.delivery);
      if($('#checkout-total'))$('#checkout-total').textContent=money(sum()+state.delivery);
    }
  });
  document.addEventListener('keydown',e=>{if(e.key==='Escape'&&$('dialog[open]')){e.preventDefault();closeAll();return;}if(e.target.matches('[data-action="zoom"]')&&['Enter',' '].includes(e.key)){e.preventDefault();e.target.click();}});
  $$('dialog').forEach(d=>{
    d.addEventListener('close',()=>{if(!$('dialog[open]'))document.body.style.overflow='';});
    d.addEventListener('click',e=>{if(e.target===d){const r=d.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)d.close();}});
  });
  window.addEventListener('hashchange',route);
  paintIcons();route();
})();

